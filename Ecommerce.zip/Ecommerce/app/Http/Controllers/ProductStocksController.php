<?php

namespace App\Http\Controllers;

use App\Stock;
use Illuminate\Http\Request;

class ProductStocksController extends Controller
{
    //
}
