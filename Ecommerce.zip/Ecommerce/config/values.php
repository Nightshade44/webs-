<?php
return [
  'STRIPE_SECRET' => env('STRIPE_SECRET')
];