﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class UserControl1 : UserControl
    {
        private string bornPlace;
        private string nickname;
        private string lastName;
        private string surename;
        private string professionName;
        private int ranking;

        public UserControl1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public string BornPlace
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }

        public string Nickname
        {
            get { return textBox2.Text; }
            set { textBox2.Text = value; }
        }

        public string LastName
        {
            get { return textBox3.Text; }
            set { textBox3.Text = value; }
        }

        public string Surename
        {
            get { return textBox4.Text; }
            set { textBox4.Text = value; }
        }

        public string ProfessionName
        {
            get { return textBox5.Text; }
            set { textBox5.Text = value; }
        }

        public string Ranking
        {
            get { return textBox6.Text; }
            set { textBox6.Text = value; }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bornPlace = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            nickname = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            lastName = textBox3.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            surename = textBox4.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            professionName = textBox5.Text;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            int.TryParse(textBox6.Text, out ranking);
        }
    }
}
