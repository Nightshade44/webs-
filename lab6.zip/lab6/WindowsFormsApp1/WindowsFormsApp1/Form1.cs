﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private UserControl1 userControl1;

        public Form1()
        {
            InitializeComponent();
            userControl1 = new UserControl1(); 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // This is empty because we handle the changes in the button click event.
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // This is empty because we handle the changes in the button click event.
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // This is empty because we handle the changes in the button click event.
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            // This is empty because we handle the changes in the button click event.
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            // This is empty because we handle the changes in the button click event.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tursunGazar = textBox1.Text;   // Change variable names here
            string urgiinOvog = textBox2.Text;    // Change variable names here
            string ovog = textBox3.Text;          // Change variable names here
            string ner = textBox4.Text;           // Change variable names here
            string ajil = textBox5.Text;          // Change variable names here
            string albanTushaal = textBox6.Text;  // Change variable names here

            if (!string.IsNullOrEmpty(tursunGazar) && !string.IsNullOrEmpty(urgiinOvog) &&
                !string.IsNullOrEmpty(ovog) && !string.IsNullOrEmpty(ner) &&
                !string.IsNullOrEmpty(ajil) && !string.IsNullOrEmpty(albanTushaal))
            {
                userControl1.BornPlace = tursunGazar;
                userControl1.Nickname = urgiinOvog;
                userControl1.LastName = ovog;
                userControl1.Surename = ner;
                userControl1.ProfessionName = ajil;
                userControl1.Ranking = albanTushaal;
                MessageBox.Show("amjilttai hadgalagdlaa");

                // Retrieve and display the values from UserControl1
                string storedTursunGazar = userControl1.BornPlace;
                string storedUrgiinOvog = userControl1.Nickname;
                string storedOvog = userControl1.LastName;
                string storedNer = userControl1.Surename;
                string storedAjil = userControl1.ProfessionName;
                string storedAlbanTushaal = userControl1.Ranking;

            }
            else
            {
                MessageBox.Show("bugdiig n nuhuj biceerei.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string storedTursunGazar = userControl1.BornPlace;
            string storedUrgiinOvog = userControl1.Nickname;
            string storedOvog = userControl1.LastName;
            string storedNer = userControl1.Surename;
            string storedAjil = userControl1.ProfessionName;
            string storedAlbanTushaal = userControl1.Ranking;

            MessageBox.Show($" UserControl1t hadgalagdsn utguud :\n" +
                $"Tursun Gazar: {storedTursunGazar}\n" +
                $"Urgiin Ovog: {storedUrgiinOvog}\n" +
                $"Ovog: {storedOvog}\n" +
                $"Ner: {storedNer}\n" +
                $"Ajil: {storedAjil}\n" +
                $"Alban Tushaal: {storedAlbanTushaal}");
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
 
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            string birthdateText = textBox8.Text;

            if (DateTime.TryParseExact(birthdateText, "yyyy.MM.dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime birthdate))
            {

                int age = CalculateAge(birthdate);

                textBox9.Text = age.ToString();
            }
            else
            {

                textBox9.Text = "Jil.Sar.Udur iim helbereer oruulna uu";
            }
        }

        private int CalculateAge(DateTime birthdate)
        {

            DateTime today = DateTime.Today;
            int age = today.Year - birthdate.Year;

            if (birthdate > today.AddYears(-age))
            {
                age--;
            }

            return age;
        }


        private int CalculateAge(int birthYear, DateTime birthdate)
        {
            DateTime today = DateTime.Today;
            int age = today.Year - birthYear;

            if (birthdate.Date > today.AddYears(-age))
            {
                age--;
            }

            return age;
        }


        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int totalWorkedYears))
            {
                long result = totalWorkedYears * 950000;

                textBox10.Text = result.ToString() + " төгрөг";
            }
            else
            {

                textBox10.Text = "buruu utga oruulsan bn";
            }
        }

    }

}
